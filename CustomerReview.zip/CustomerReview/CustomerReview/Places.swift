//
//  Places.swift
//  CustomerReview
//
//  Created by MacStudent on 2018-08-11.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Places{
    static var titles : [String] = ["Richmond","George","Blaze","Miku","Alo","CNtower","Museum","Artgallery","Niagara","Highpark","Hilton","Bondplace","Doubletree","Delta","Westinprince"]
    static var des : [String] 
    static var images : [String] = ["Richmond","George","Blaze","Miku","Alo","CNtower","Museum","Artgallery","Niagara","Highpark","Hilton","Bondplace","Doubletree","Delta","Westinprince"]
    
}
