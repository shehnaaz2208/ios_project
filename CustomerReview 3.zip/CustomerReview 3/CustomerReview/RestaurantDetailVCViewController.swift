//
//  RestaurantDetailVCViewController.swift
//  CustomerReview
//
//  Created by MacStudent on 2018-08-16.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class RestaurantDetailVCViewController: UIViewController {

  
    @IBOutlet weak var lblDescription: UILabel!
    @IBOutlet weak var lblRestaurant: UILabel!
    @IBOutlet weak var imgRes: UIImageView!
    var plistArray = NSMutableArray()
    var selectedRestaurant: Int?
    
    override func viewWillAppear(_ animated: Bool) {
        if let index = selectedRestaurant{
            self.fetchrestaurantDetails()
            self.displayDetails()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func displayDetails(){
        lblRestaurant.text = Description.restaurants[self.selectedRestaurant!]
        let restaurantDetails = plistArray[self.selectedRestaurant!] as! NSMutableDictionary
        self.lblDescription.text = restaurantDetails.value(forKey: "des") as? String
        self.imgRes.image = restaurantDetails.value(forKey: "image") as! UIImage
    }
    func fetchrestaurantDetails(){
        if let filePath = Bundle.main.path(forResource: "RestaurantList", ofType: "plist"){
            //get an array representation of plist
            plistArray = NSMutableArray(contentsOfFile: filePath)!
            
            print("plistArray \(plistArray)")
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
