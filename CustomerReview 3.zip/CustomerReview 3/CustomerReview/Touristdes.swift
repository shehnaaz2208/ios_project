//
//  Touristdes.swift
//  CustomerReview
//
//  Created by MacStudent on 2018-08-17.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Tourist{
     static var TName : [String] = ["CNtower","Museum","Artgallery","Niagara Falls","Highpark"]
    
    static var TDes : [String] = ["The CN Tower's 350-metre high revolving restaurant offers regional Canadian fare & panoramic views","The Royal Ontario Museum is a museum of art, world culture and natural history in Toronto, Ontario, Canada. It is one of the largest museums in North America, and the largest in Canada","Opened in 1997, this cultural center hosts rotating & permanent art exhibitions, classes & events","Niagara Falls, Ontario, is a Canadian city at the famous waterfalls of the same name, linked with the U.S. by the Rainbow Bridge","High Park is a municipal park in Toronto, Ontario, Canada. It spans 161 hectares, and is a mixed recreational and natural park, with sporting facilities, cultural facilities, educational facilities, gardens, playgrounds and a zoo"]
    static var Timage : [String] = ["CNtower","Museum","Artgallery","Niagara Falls","Highpark"]
    
    
    
}
