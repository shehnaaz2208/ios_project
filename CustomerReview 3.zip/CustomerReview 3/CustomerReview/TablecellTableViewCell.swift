//
//  TablecellTableViewCell.swift
//  CustomerReview
//
//  Created by MacStudent on 2018-08-11.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class TablecellTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var imgres: UIImageView!
    
    @IBOutlet weak var btnrest: UIButton!
    
    @IBOutlet weak var btnhotel: UIButton!
    @IBOutlet weak var btntourist: UIButton!
    
//    @IBAction func btnRestaurant(_ sender: UIButton) {
//        let mainSB: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//        let tableVC = mainSB.instantiateViewController(withIdentifier: "HomeScene")
//        navigationController?.pushViewController(tableVC, animated: true)
//    }
    

   
    
}
